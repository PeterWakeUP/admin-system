package com.tcshipin.video;

import com.tcshipin.server.DataChannelServerApplication;
import com.tcshipin.server.modules.video.entity.VideoLookDetail;
import com.tcshipin.server.modules.video.service.UserVideoLookDetailService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = DataChannelServerApplication.class)
public class mybatisTests {

	@Autowired
	UserVideoLookDetailService videoLookDetailService;

	@Test
	public void saveVideoDetail() {
		/*VideoLookDetail videoLookDetail = new VideoLookDetail();
		videoLookDetail.setDuration("10");
		videoLookDetail.setVideoId("1L");
		videoLookDetail.setUserid("1L");
		videoLookDetailService.saveUserVideoLookDetail(videoLookDetail);*/
	}

}
